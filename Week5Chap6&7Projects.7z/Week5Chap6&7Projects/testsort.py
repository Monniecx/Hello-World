def isSorted(lst):
    for i in range(len(lst) - 1):
        if lst[i] > lst[i + 1]:
            return False
    return True


print("Testing isSorted function:")
print(isSorted([]))              
print(isSorted([1]))            
print(isSorted([1, 2, 3, 4]))  
print(isSorted([1, 1, 2, 3]))     
print(isSorted([3, 2, 1]))        
print(isSorted([1, 3, 2, 4]))     
