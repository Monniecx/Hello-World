def inputFloat(prompt):
    while True:
        user_input = input(prompt)
        try:
            value = float(user_input)
            return value
        except ValueError:
            print("Invalid input. Please enter a valid floating-point number.")


if __name__ == "__main__":
    print("Testing inputFloat function")
    number = inputFloat("Enter a floating-point number: ")
    print("You entered:", number)
