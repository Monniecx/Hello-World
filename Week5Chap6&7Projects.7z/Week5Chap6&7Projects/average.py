def get_average_from_file(filename):
    with open(filename, 'r') as file:
        
        numbers = list(map(float, file.readlines()))
        if len(numbers) == 0:
            return 0  
        return sum(numbers) / len(numbers)


if __name__ == "__main__":
    filename = input("Enter the name of the text file: ")
    try:
        average = get_average_from_file(filename)
        print("Average:", average)
    except FileNotFoundError:
        print("File not found.")
    except ValueError:
        print("File contains invalid numbers.")
