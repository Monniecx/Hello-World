# encrypt.py

import string

def caesar_encrypt(text, shift):
    printable = string.printable  
    encrypted = ''
    
    for char in text:
        if char in printable:
            index = printable.index(char)
            new_index = (index + shift) % len(printable)
            encrypted += printable[new_index]
        else:
            encrypted += char  
            
    return encrypted

def main():
    plaintext = input("Enter text to encrypt: ")
    try:
        shift = int(input("Enter shift distance: "))
    except ValueError:
        print("Shift must be an integer.")
        return
    
    encrypted_text = caesar_encrypt(plaintext, shift)
    print("Encrypted text:", encrypted_text)

if __name__ == "__main__":
    main()
