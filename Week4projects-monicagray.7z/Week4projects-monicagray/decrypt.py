# decrypt.py

import string

def caesar_decrypt(text, shift):
    printable = string.printable  
    decrypted = ''
    
    for char in text:
        if char in printable:
            index = printable.index(char)
            new_index = (index - shift) % len(printable)
            decrypted += printable[new_index]
        else:
            decrypted += char  
    
    return decrypted

def main():
    encrypted_text = input("Enter text to decrypt: ")
    try:
        shift = int(input("Enter shift distance: "))
    except ValueError:
        print("Shift must be an integer.")
        return
    
    decrypted_text = caesar_decrypt(encrypted_text, shift)
    print("Decrypted text:", decrypted_text)

if __name__ == "__main__":
    main()
