# copyfile.py

source_file = input("Enter the name of the source file: ")
dest_file = input("Enter the name of the destination file: ")

try:
    with open(source_file, 'r') as src:
        contents = src.read()

    with open(dest_file, 'w') as dst:
        dst.write(contents)

    print("File copied successfully.")
except:
    print("An error occurred.")
