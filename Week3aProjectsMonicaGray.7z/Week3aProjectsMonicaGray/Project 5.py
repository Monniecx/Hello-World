# Get user inputs
initial_population = int(input("Enter the initial number of organisms: "))
growth_rate = float(input("Enter the growth rate: "))
growth_period = int(input("Enter the number of hours to achieve this growth rate: "))
total_hours = int(input("Enter the total number of hours for population growth: "))

# Calculate the number of growth cycles
cycles = total_hours // growth_period

# Compute final population
final_population = initial_population * (growth_rate ** cycles)

# Display the result
print("Predicted population after", total_hours, "hours:", int(final_population))
