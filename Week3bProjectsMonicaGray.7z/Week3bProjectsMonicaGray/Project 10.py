# Get the purchase price from the user
purchase_price = float(input("Enter the purchase price: "))

# Constants
down_payment = 0.10 * purchase_price
balance = purchase_price - down_payment
monthly_payment = 0.05 * purchase_price
annual_interest_rate = 0.12

print("\nTidBit Payment Schedule")
print("Month | Balance   | Interest | Principal | Payment  | New Balance")
print("---------------------------------------------------------------")

month = 1
current_balance = balance

while current_balance > 0:
    interest = current_balance * (annual_interest_rate / 12)
    principal = monthly_payment - interest

    # Adjust final payment if needed
    if current_balance < monthly_payment:
        monthly_payment = current_balance + interest
        principal = current_balance

    new_balance = current_balance - principal

    # Display the payment information
    print(f"{month:5} | ${current_balance:8.2f} | ${interest:7.2f} | ${principal:8.2f} | ${monthly_payment:8.2f} | ${new_balance:11.2f}")

    # Prepare for next month
    current_balance = new_balance
    month += 1
