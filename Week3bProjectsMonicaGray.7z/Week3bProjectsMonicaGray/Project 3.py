import math

low = int(input("Enter the lower bound: "))
high = int(input("Enter the upper bound: "))
max_guesses = math.ceil(math.log2(high - low + 1))

print(f"Think of a number between {low} and {high}.")
print(f"I'll guess it in at most {max_guesses} tries.")

guesses = 0

while low <= high:
    guess = (low + high) // 2
    guesses += 1
    print(f"My guess #{guesses}: {guess}")
    reply = input("Is it (h)igh, (l)ow, or (c)orrect? ").lower()

    if reply == 'c':
        print(f"I guessed it! Your number is {guess}.")
        break
    elif reply == 'h':
        low = guess + 1
    elif reply == 'l':
        high = guess - 1
    else:
        print("Please enter h, l, or c.")

    if low > high:
        print("That can't be! No number fits your answers. Are you cheating?")
        break
