
# Get the length of the cube's edge from the user
edge_length = int(input("Enter the length of an edge of the cube: "))

# Calculate the surface area of the cube
surface_area = 6 * (edge_length ** 2)

# Print the surface area
print("The surface area of the cube is:", surface_area)
