
import math

# Get the radius of the sphere from the user
radius = float(input("Enter the radius of the sphere: "))

# Calculate the diameter
diameter = 2 * radius

# Calculate the circumference (of a great circle)
circumference = 2 * math.pi * radius

# Calculate the surface area
surface_area = 4 * math.pi * (radius ** 2)

# Calculate the volume
volume = (4/3) * math.pi * (radius ** 3)

# Print all results
print("Diameter:", diameter)
print("Circumference:", circumference)
print("Surface Area:", surface_area)
print("Volume:", volume)
