
# Get the mass of the object from the user
mass = float(input("Enter the mass of the object (in kilograms): "))

# Get the velocity of the object from the user
velocity = float(input("Enter the velocity of the object (in meters per second): "))

# Calculate momentum (p = m * v)
momentum = mass * velocity

# Print the result
print("The momentum of the object is:", momentum, "kg·m/s")
