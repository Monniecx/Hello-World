def mean(numbers):
    if not numbers:
        return 0
    return sum(numbers) / len(numbers)

def median(numbers):
    if not numbers:
        return 0

    sorted_numbers = sorted(numbers)
    n = len(sorted_numbers)
    mid = n // 2

    if n % 2 == 0:
        return (sorted_numbers[mid - 1] + sorted_numbers[mid]) / 2
    else:
        return sorted_numbers[mid]

def mode(numbers):
    if not numbers:
        return 0

    freq = {}
    for num in numbers:
        freq[num] = freq.get(num, 0) + 1

    max_count = max(freq.values())
    modes = [num for num, count in freq.items() if count == max_count]

    if len(modes) == 1:
        return modes[0]
    else:
        
        return min(modes)

def main():
    sample_data = [1, 2, 2, 3, 4, 5, 5, 5, 6]

    print("Data:", sample_data)
    print("Mean:", mean(sample_data))
    print("Median:", median(sample_data))
    print("Mode:", mode(sample_data))


if __name__ == "__main__":
    main()
