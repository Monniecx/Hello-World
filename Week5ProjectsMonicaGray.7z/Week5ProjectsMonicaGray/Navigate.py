def main():
    
    filename = input("Enter the filename: ")

    try:
       
        with open(filename, 'r') as file:
            lines = file.readlines()

        
        lines = [line.strip() for line in lines]

       
        print(f"\nThe file has {len(lines)} lines.")

        while True:
            
            try:
                choice = int(input("Enter a line number (0 to quit): "))

                if choice == 0:
                    print("Exiting the program.")
                    break
                elif 1 <= choice <= len(lines):
                                       print(f"Line {choice}: {lines[choice - 1]}")
                else:
                    print("Invalid line number. Please try again.")
            except ValueError:
                print("Please enter a valid number.")
    except FileNotFoundError:
        print("File not found. Please check the filename and try again.")


if __name__ == "__main__":
    main()
